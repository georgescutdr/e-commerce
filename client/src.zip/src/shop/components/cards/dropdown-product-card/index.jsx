import React from 'react';
import { FiTrash2 } from 'react-icons/fi';
import { Link } from 'react-router-dom';
import './dropdown-product-card.css';

export const DropdownProductCard = ({ item, onRemove }) => {
    if (!item) return null;

    const image = item.image
        ? `/public/uploads/product/${item.id}/${item.image}`
        : `/public/uploads/default-image.jpg`;

    return (
        <div className="dropdown-product-card">
            <img className="product-image" src={image} alt={item.name} />
            <div className="product-info">
                <Link to={`/${item.name}/pd/${item.id}/view_product`} className="product-title-link">
                    <span className="product-title">{item.name}</span>
                </Link>
                <span className="product-price">${Number(item.price).toFixed(2)}</span>
            </div>
            <div className="product-meta">
                <span className="product-quantity">Qty: {item.quantity}</span>
                <button className="remove-btn" onClick={() => onRemove?.(item.id)}>
                    <FiTrash2 />
                </button>
            </div>
        </div>
    );
};
