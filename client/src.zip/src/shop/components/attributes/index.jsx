import React, { useEffect, useState } from 'react';
import { capitalize } from '../../../utils'
import './attributes.css';

export const Attributes = ({ items = [] }) => {
    const [uniqueAttributes, setUniqueAttributes] = useState([]);

    useEffect(() => {
        const deduplicated = Array.from(
            new Map(items.filter(attr => attr && attr.id).map(attr => [attr.id, attr])).values()
        );
        setUniqueAttributes(deduplicated);
    }, [items]);

    return (
        <div className="attributes-style">
            <h4 className="attributes-title">Product Features</h4>
            {uniqueAttributes.length === 0 ? (
                <p className="attributes-empty">No attributes available</p>
            ) : (
                <table className="attributes-table">
                    <tbody>
                        {uniqueAttributes.map((item, index) => (
                            <tr key={item.id || index}>
                                <td className="attribute-name">{capitalize(item.name)}</td>
                                <td className="attribute-value">{item.value}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    );
};
