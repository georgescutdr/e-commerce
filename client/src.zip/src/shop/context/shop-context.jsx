import { createContext, useState, useEffect, useContext } from "react";
import Cookies from "js-cookie";

export const ShopContext = createContext();

export const ShopContextProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState(() => {
    const stored = Cookies.get('cartItems');
    return stored ? JSON.parse(stored) : {};
  });

  const [total, setTotal] = useState(0);

  useEffect(() => {
    Cookies.set('cartItems', JSON.stringify(cartItems), { expires: 7 });
    computeTotal(cartItems);
  }, [cartItems]);

  const addToCart = (product) => {
    setCartItems(prev => {
      const prevQuantity = prev[product.id]?.quantity || 0;
      return {
        ...prev,
        [product.id]: {
          ...product,
          quantity: prevQuantity + 1,
          vouchers: prev[product.id]?.vouchers || [] // Ensure vouchers are initialized
        },
      };
    });
  };

  const removeFromCart = (productId) => {
    setCartItems(prev => {
      const updated = { ...prev };
      delete updated[productId];
      return updated;
    });
  };

  const updateQuantity = (productId, quantity) => {
    setCartItems(prev => ({
      ...prev,
      [productId]: {
        ...prev[productId],
        quantity: quantity < 1 ? 1 : quantity,
      },
    }));
  };

  // Apply voucher globally across multiple products
  const applyVoucherGlobally = (voucher, productIds = []) => {
    setCartItems(prev => {
      const updatedCart = { ...prev };

      productIds.forEach(pid => {
        const product = updatedCart[pid];
        if (!product) return;

        const existingVouchers = product.vouchers || [];
        const alreadyApplied = existingVouchers.some(v => v.code === voucher.code);
        if (alreadyApplied) return;

        updatedCart[pid] = {
          ...product,
          vouchers: [...existingVouchers, voucher],
        };
      });

      computeTotal(updatedCart);
      return updatedCart;
    });
  };

  // Apply voucher to a specific product
  const applyVoucherToProduct = (voucher, productId) => {
    applyVoucherGlobally(voucher, [productId]);
  };

  const computeTotal = (cart) => {
    let newTotal = 0;
    Object.values(cart).forEach((item) => {
      let itemPrice = item.price * item.quantity;
      if (item.vouchers) {
        item.vouchers.forEach(voucher => {
          const discount = voucher.type === 'percentage'
            ? (item.price * voucher.value) / 100
            : voucher.value;
          itemPrice -= discount;
        });
      }
      newTotal += itemPrice;
    });
    setTotal(newTotal);
  };

  return (
    <ShopContext.Provider value={{
      cartItems,
      addToCart,
      removeFromCart,
      updateQuantity,
      applyVoucherToProduct,
      applyVoucherGlobally,
      total,
    }}>
      {children}
    </ShopContext.Provider>
  );
};

export const useShop = () => useContext(ShopContext);
