import React, { useRef } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';
import { Button } from 'primereact/button';
import { Toast } from 'primereact/toast';
import Axios from 'axios';
import './contact-form.css';

const ContactForm = ({ props }) => {
	const { control, handleSubmit, formState: { errors }, reset } = useForm();
	const toast = useRef(null);

	const onSubmit = async (data) => {
		try {
			const response = await Axios.post('/api/contact', data);

			if (response.status === 200) {
				toast.current.show({
					severity: 'success',
					summary: 'Message Sent',
					detail: 'We have received your message.',
					life: 3000,
				});
				reset();
			} else {
				toast.current.show({
					severity: 'error',
					summary: 'Error',
					detail: 'Something went wrong.',
					life: 3000,
				});
			}
		} catch (error) {
			toast.current.show({
				severity: 'error',
				summary: 'Error',
				detail: 'Failed to send message.',
				life: 3000,
			});
		}
	};

	return (
		<div className="contact-form-wrapper">
			<Toast ref={toast} />
			<form className="contact-form" onSubmit={handleSubmit(onSubmit)}>
				{props.fields.map((field, index) => {
					const isTextArea = field.type === 'textarea';
					const inputId = `${field.name}_${index}`; // handle potential duplicates

					return (
						<div className="form-field" key={inputId}>
							<label htmlFor={inputId}>{field.label}</label>
							<Controller
								name={field.name}
								control={control}
								rules={{ required: `${field.label} is required.` }}
								render={({ field: controllerField }) =>
									isTextArea ? (
										<InputTextarea {...controllerField} id={inputId} rows={4} />
									) : (
										<InputText {...controllerField} id={inputId} type={field.type} />
									)
								}
							/>
							{errors[field.name] && (
								<small className="p-error">{errors[field.name].message}</small>
							)}
						</div>
					);
				})}

				<Button type="submit" label="Send Message" className="mt-4" />
			</form>
		</div>
	);
};

export default ContactForm;
