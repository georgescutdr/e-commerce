import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShopContext } from '../../context/shop-context';
import { CheckoutButton } from '../../components/checkout-button';
import { Button } from 'primereact/button'; // PrimeReact Button for style
import './shopping-cart.css'; // Add any specific styles here

const ShoppingCart = () => {
  const { cartItems, updateQuantity, removeFromCart, total } = useContext(ShopContext);
  const items = Object.values(cartItems);

  const navigate = useNavigate();

  const handleCheckoutClick = () => {
    navigate('/checkout');
  };

  return (
    <div className="shopping-cart-container">
      <h2>Shopping Cart</h2>
      {items.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <>
          <table className="shopping-cart-table">
            <thead>
              <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total</th>
                <th>Remove</th>
              </tr>
            </thead>
            <tbody>
              {items.map(({ id, brand, name, price, quantity, vouchers }) => (
                <tr key={id}>
                  <td>
                    {brand} {name}
                    {vouchers && vouchers.length > 0 && (
                      <div className="vouchers">
                        <strong>Applied Vouchers:</strong>
                        <ul>
                          {vouchers.map((voucher, index) => (
                            <li key={index}>
                              {voucher.name} - {voucher.code}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </td>
                  <td>${price.toFixed(2)}</td>
                  <td>
                    <input
                      type="number"
                      min="1"
                      value={quantity}
                      onChange={(e) => updateQuantity(id, parseInt(e.target.value))}
                      className="quantity-input"
                    />
                  </td>
                  <td>${(price * quantity).toFixed(2)}</td>
                  <td>
                    <Button
                      label="Remove"
                      icon="pi pi-times"
                      onClick={() => removeFromCart(id)}
                      className="p-button-danger p-button-text"
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="cart-summary">
            <h3>Total: ${total.toFixed(2)}</h3>
            <div className="checkout-button-container">
              <Button
                label="Proceed to Checkout"
                icon="pi pi-shopping-cart"
                onClick={handleCheckoutClick}
                className="p-button-success p-button-rounded"
              />
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default ShoppingCart;
